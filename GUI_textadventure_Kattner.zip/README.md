# GUI_TEXT_ADVENTURE_OOP

A GUI based text adventure for school

# Instructions

just download an start the main.exe in the dist folder or clone the repo and run main.py (need to install all dependencies into your python env )

# DISCLAIMER

### Story langweilig aber wenigstens dadurch realitätsnah.

### gibt kein Ende auser TOT. So wie es auch in Real Life oder Hypixel Skyblock ist. Ein wahres grind game.

### Nicht alles wurd selber geschrieben (trotzdem prob mehr als bei 90% der Klasse. Wollte keine Sehnenscheidenentzündung. Tut in letzter Zeit von Tennis eh wieder weh.)


### Well. DANKE FÜR DIE KRÜCKE Deepseek (besser als chatty, wobei copilot in vscode auch goated ist). 
Auch großen dank an spotify und tiktok brainrot. 
Ohne euch wär das ehrlich nicht möglich gewesen. (solo leveling mad overrated.
Frieren war peak. From Bureaucrat to Villainess: Dad's Been Reincarnated!  auch lustig.)

## Viel Spaß liebe Grüße Kattner 

## 08.04.2025 20:01 Uhr


